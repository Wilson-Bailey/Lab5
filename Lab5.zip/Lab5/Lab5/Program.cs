﻿using Lab5;
using System.Text.Json;


class Program
{
    static async Task Main()
    {
        // Define the API endpoint and parameters
        string apiUrl = "https://www.freetogame.com/api/games?platform=pc";

        // Call the FreeToGame API to get the list of games
        List<Game> games = await GetGames(apiUrl);

        if (games != null && games.Count > 0)
        {
            // Display information about all the games
            DisplayGameList(games);
        }
        else
        {
            Console.WriteLine("No free-to-play games found.");
        }
    }

    static async Task<List<Game>> GetGames(string apiUrl)
    {
        using (HttpClient client = new HttpClient())
        {
            try
            {
                // Make a GET request to the FreeToGame API
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                // Check if the request was successful (status code 200)
                if (response.IsSuccessStatusCode)
                {
                    // Read the response content as a string
                    string responseContent = await response.Content.ReadAsStringAsync();

                    // Deserialize the JSON directly into a list of games
                    List<Game> games = JsonSerializer.Deserialize<List<Game>>(responseContent, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    return games;
                }

                // If the request was not successful or no games were found, return null
                Console.WriteLine($"Error: {response.StatusCode}");
                return null;
            }
            catch (Exception ex)
            {
                // Handle exceptions
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }
    }

    static void DisplayGameList(List<Game> games)
    {
        // Display information about all games
        foreach (var game in games)
        {
            Console.WriteLine($"Title: {game.title}");
            Console.WriteLine($"Thumbnail: {game.thumbnail}");
            Console.WriteLine($"Description: {game.short_description}");
            Console.WriteLine($"Genre: {game.genre}");
            Console.WriteLine($"Platform: {game.platform}");
            Console.WriteLine($"Publisher: {game.publisher}");
            Console.WriteLine($"Developer: {game.developer}");
            Console.WriteLine($"Release Date: {game.release_date:yyyy-MM-dd}");
            Console.WriteLine($"FreeToGame Profile Url: {game.freetogame_profile_url}");
            Console.WriteLine(new string('-', 120)); // Separator line
        }
    }
}
